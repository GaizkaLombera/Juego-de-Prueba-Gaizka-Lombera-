import { Component } from '@angular/core';

@Component({
  selector: 'app-cta',
  standalone: false,

  templateUrl: './cta.component.html',
  styleUrl: './cta.component.scss'
})
export class CTAComponent {
  cardsData = [
    {
      title: 'Tienda online',
      text: 'Mauris et turpis tellus. Nullam facilisis, arcu quis lobortis gravida.'
    },
    {
      title: 'Administración pública',
      text: 'Mauris et turpis tellus. Nullam facilisis, arcu quis lobortis gravida.'
    },
    {
      title: 'Fabricamos a medida',
      text: 'Mauris et turpis tellus. Nullam facilisis, arcu quis lobortis gravida.'
    },
    {
      title: 'Digitalización accesible',
      text: 'Mauris et turpis tellus. Nullam facilisis, arcu quis lobortis gravida.'
    }
  ];
}
