import { Component } from '@angular/core';

@Component({
  selector: 'app-news',
  standalone: false,

  templateUrl: './news.component.html',
  styleUrl: './news.component.scss'
})
export class NewsComponent {
  items = [
    { image: '/carousel1-1.png', title: 'Manual de señalización accesible para un mundo más inclusivo', type: 'Señalética' },
    { image: '/carousel1-2.png', title: '¿Tienes cita en Fitur? La accesibilidad estará en tu agenda', type: 'Turismo' },
    { image: '/carousel1-3.jpeg', title: '¿Tienes cita en Fitur? La accesibilidad estará en tu agenda', type: 'Turismo' },
    { image: '/carousel1-4.png', title: 'Piensa en más accesibilidad para personas con Asperger', type: 'Análisis' },
    { image: '/carousel1-5.jpeg', title: 'Polideportivos con accesibilidad en Bilbao Kirolak', type: 'Proyecto' },
  ];

  activeIndex = 0;

  moveLeft(): void {
    this.activeIndex = (this.activeIndex > 0) ? this.activeIndex - 1 : this.items.length - 1;
  }

  moveRight(): void {
    this.activeIndex = (this.activeIndex < this.items.length - 1) ? this.activeIndex + 1 : 0;
  }
}
