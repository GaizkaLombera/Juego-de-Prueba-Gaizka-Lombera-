import { Component } from '@angular/core';

@Component({
  selector: 'app-logos',
  standalone: false,
  
  templateUrl: './logos.component.html',
  styleUrl: './logos.component.scss'
})
export class LogosComponent {

}
