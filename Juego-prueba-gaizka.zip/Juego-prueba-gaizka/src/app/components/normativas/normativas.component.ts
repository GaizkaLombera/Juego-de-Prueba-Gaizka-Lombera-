import { Component } from '@angular/core';

@Component({
  selector: 'app-normativas',
  standalone: false,
  
  templateUrl: './normativas.component.html',
  styleUrl: './normativas.component.scss'
})
export class NormativasComponent {

}
