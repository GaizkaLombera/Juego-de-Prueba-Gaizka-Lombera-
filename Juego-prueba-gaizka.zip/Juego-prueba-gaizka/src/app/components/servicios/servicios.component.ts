import { Component } from '@angular/core';

@Component({
  selector: 'app-servicios',
  standalone: false,

  templateUrl: './servicios.component.html',
  styleUrl: './servicios.component.scss'
})
export class ServiciosComponent {
  cardsData = [
    {
      title: "Accesibilidad en comunicación",
      text: "Mauris et turpis tellus. Nullam facilisis, arcu quis lobortis gravida."
    },
    {
      title: "Servicios de digitalización",
      text: "Nullam facilisis ligula et enim ultrices sagittis Aenean at felis eget."
    },
    {
      title: "Diagnósticos y planes estratégicos",
      text: "Aliquam vitae mauris non augue sollicitudin porttitorodio vehicula."
    },
    {
      title: "Evacuación y emergencia",
      text: "Donec et nibh facilisis, lobortis lacus non, viverra ante integer."
    },
    {
      title: "Formación en inclusión",
      text: "Nullam facilisis ligula et enim ultrices sagittis Aenean at felis eget."
    },
    {
      title: "Restauración inclusiva",
      text: "Donec et nibh facilisis, lobortis lacus non, viverra ante integer."
    },
    {
      title: "Simulación de entornos 3D",
      text: "Donec et nibh facilisis, lobortis lacus non, viverra ante integer."
    }
  ];

}
