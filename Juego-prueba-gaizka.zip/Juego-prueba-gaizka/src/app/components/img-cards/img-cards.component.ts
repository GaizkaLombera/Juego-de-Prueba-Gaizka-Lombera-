import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-img-cards',
  standalone: false,
  
  templateUrl: './img-cards.component.html',
  styleUrl: './img-cards.component.scss'
})
export class ImgCardsComponent {
  @Input() data!: { classType: string; alt: string };

}
