import { Component } from '@angular/core';

@Component({
  selector: 'app-who-we-are',
  standalone: false,
  
  templateUrl: './who-we-are.component.html',
  styleUrl: './who-we-are.component.scss'
})
export class WhoWeAreComponent {

}
