import { Component } from '@angular/core';

@Component({
  selector: 'app-products',
  standalone: false,

  templateUrl: './products.component.html',
  styleUrl: './products.component.scss'
})
export class ProductsComponent {
  imgCardsData = [
    {
      alt: 'Señalización. Diseño y fabricación',
      classType: 'card1'
    },
    {
      alt: 'Planos y cuadros tactovisuales',
      classType: 'card2'
    },
    {
      alt: 'Papelería, vinilos y etiquetas',
      classType: 'card3'
    },
    {
      alt: 'Pavimento tactil',
      classType: 'card4'
    }
  ];


}
