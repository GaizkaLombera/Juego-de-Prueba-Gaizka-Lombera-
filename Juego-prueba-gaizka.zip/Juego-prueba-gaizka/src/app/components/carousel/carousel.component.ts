import { Component } from '@angular/core';

@Component({
  selector: 'app-carousel',
  standalone: false,

  templateUrl: './carousel.component.html',
  styleUrl: './carousel.component.scss'
})
export class CarouselComponent {
  items = [
    { image: '/carousel2-1.png', title: 'Manual de señalización accesible para un mundo más inclusivo', location: 'Palma de Mallorca' },
    { image: '/carousel2-2.png', title: 'La estrategia integral para el fomento de la accesibilidad en bilbobus', location: 'Bilbao' },
    { image: '/carousel2-3.png', title: 'Alhóndiga Bilbao – Centro Azkuna, pensando en la accesibilidad para todos', location: 'Bilbao' },
    { image: '/carousel2-4.jpeg', title: 'Vilamuseu «museos para todos»', location: 'Vila Joiosa' },
    { image: '/carousel2-5.png', title: 'La accesibilidad en el turismo entra ya al siguiente nivel', location: 'Getxo' },
  ];

  activeIndex = 0;

  moveLeft(): void {
    this.activeIndex = (this.activeIndex > 0) ? this.activeIndex - 1 : this.items.length - 1;
  }

  moveRight(): void {
    this.activeIndex = (this.activeIndex < this.items.length - 1) ? this.activeIndex + 1 : 0;
  }
}
