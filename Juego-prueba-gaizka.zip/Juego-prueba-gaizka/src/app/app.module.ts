import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { NormativasComponent } from './components/normativas/normativas.component';
import { CTAComponent } from './components/cta/cta.component';
import { ServiciosComponent } from './components/servicios/servicios.component';
import { CardsComponent } from './components/cards/cards.component';
import { WhoWeAreComponent } from './components/who-we-are/who-we-are.component';
import { ImgCardsComponent } from './components/img-cards/img-cards.component';
import { ProductsComponent } from './components/products/products.component';
import { FooterComponent } from './components/footer/footer.component';
import { CarouselComponent } from './components/carousel/carousel.component';
import { NewsComponent } from './components/news/news.component';
import { LogosComponent } from './components/logos/logos.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NormativasComponent,
    CTAComponent,
    ServiciosComponent,
    CardsComponent,
    WhoWeAreComponent,
    ImgCardsComponent,
    ProductsComponent,
    FooterComponent,
    CarouselComponent,
    NewsComponent,
    LogosComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
